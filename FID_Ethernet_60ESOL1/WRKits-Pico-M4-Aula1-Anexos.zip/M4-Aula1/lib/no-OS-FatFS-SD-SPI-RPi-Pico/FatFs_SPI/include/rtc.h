#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void time_init();

#ifdef __cplusplus
}
#endif
